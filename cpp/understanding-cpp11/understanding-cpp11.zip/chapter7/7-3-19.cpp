int d = 0;
int TryCapture() {
    auto ill_lambda = [d]{};
}
