/* confdefs.h */
#define PACKAGE_NAME "b64"
#define PACKAGE_TARNAME "b64"
#define PACKAGE_VERSION "1.0"
#define PACKAGE_STRING "b64 1.0"
#define PACKAGE_BUGREPORT "b64-bugs@example.com"
#define PACKAGE_URL ""
#define PACKAGE "b64"
#define VERSION "1.0"
#define STDC_HEADERS 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_STAT_H 1
