

这里的lib使用 当前master  commit:  694e8acc49e776ea8b546530f9ffc9c1b2734466
来生成的



# 遇到这种错误多执行一遍
configure.ac:20: the top level
configure:8655: error: possibly undefined macro: AM_LANGINFO_CODESET
      If this token and others are legitimate, please use m4_pattern_allow.
      See the Autoconf documentation.
autoreconf: /usr/bin/autoconf failed with exit status: 1

