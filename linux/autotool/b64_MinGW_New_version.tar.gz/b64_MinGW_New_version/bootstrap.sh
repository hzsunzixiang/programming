#!/bin/sh
#gnulib-tool --import base64

gnulib-tool --update
autoreconf -i
