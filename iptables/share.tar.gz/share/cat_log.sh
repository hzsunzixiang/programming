
tailf /var/log/iptables_warning.log
